package com.news.app.service;

import com.news.app.model.News;
import org.springframework.http.ResponseEntity;

public interface NewsService {

	public ResponseEntity<?> getNewsByCountryName(String countryName);

	public News getNewsBytitle(String title);


}

