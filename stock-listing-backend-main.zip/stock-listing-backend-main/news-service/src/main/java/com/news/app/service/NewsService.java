package com.news.app.service;

import com.news.app.model.News;
import org.springframework.http.ResponseEntity;

public interface NewsService {
	public News getNewsByTitle(String title);


}

