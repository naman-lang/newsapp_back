package com.news.app.model;
import lombok.*;


@Data
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class Source {
    private  int id;
    private  String name;

}
