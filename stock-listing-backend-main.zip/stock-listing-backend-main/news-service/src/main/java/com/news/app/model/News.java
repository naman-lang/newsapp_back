package com.news.app.model;

import lombok.*;


@Data
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class News {
	private String totalResults;
	private Object articles;
	private String source;
	private String author;
	private String title;
	private String description;
	private String content;
	private String category;
	private String publishedAt;
	private String url;
	private String urlToImage;
}

//	private String country;
//	private String type;

