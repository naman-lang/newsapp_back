package com.news.app.dto;

import java.util.List;

import com.news.app.model.News;


import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class NewsResponseDTO  {

	private List<News> data;

	public NewsResponseDTO(List<News> data) {
		super();
		this.data = data;
	}
}