package com.news.app.controller;

import java.util.List;
import java.util.Map;

import com.news.app.exception.ExternalServiceException;
import com.news.app.model.News;
import com.news.app.model.Articles;
import com.news.app.model.Source;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.news.app.exception.InvalidCredentialsException;
import com.news.app.feign.AuthClient;
import com.news.app.service.NewsService;

import feign.FeignException;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;

@RestController
@RequestMapping("/api/v1.0/news")
@CrossOrigin("*")
public class NewsController {
	private final NewsService newsService;
	private final AuthClient authClient;

	@Autowired
	public NewsController(NewsService newsService, AuthClient authClient) {
		this.newsService = newsService;
		this.authClient = authClient;
	}
	@Operation(summary = "listing News by title")
	@GetMapping("/title/{title}")
	public News getNewsByTitle(@PathVariable String title ) {
		News newsByTitle = newsService.getNewsByTitle(title);
		return  newsService.getNewsByTitle(title);
	}
}