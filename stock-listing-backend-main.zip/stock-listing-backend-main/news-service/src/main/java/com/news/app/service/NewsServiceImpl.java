package com.news.app.service;

import java.util.List;

import com.news.app.model.News;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.news.app.dto.NewsResponseDTO;

@Service
public class NewsServiceImpl implements NewsService {

	@Value("${newsapi.api.key}")
	private String apiKey;

	private static final String API_URL = "https://newsapi.org/v2/everything?q={title}&apiKey=71f8f25ba27b451bbb1ef18d883e7377";
   
	private final RestTemplate restTemplate;
    @Autowired
    public NewsServiceImpl(RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
    }

	@Override
	public News getNewsByTitle(String title){
		String apiUrl = API_URL.replace("{title}", title);
		//List<News> news = forObject.getData();
		 return restTemplate.getForObject(apiUrl, News.class);


	}

}
