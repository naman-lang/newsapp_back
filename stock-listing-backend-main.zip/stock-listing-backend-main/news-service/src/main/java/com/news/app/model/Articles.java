package com.news.app.model;
import lombok.*;


@Data
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter

public class Articles {
    private String source;
}
