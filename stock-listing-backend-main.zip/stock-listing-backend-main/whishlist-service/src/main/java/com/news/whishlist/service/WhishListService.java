package com.news.whishlist.service;

import com.news.whishlist.dto.WhishList;
import org.springframework.http.ResponseEntity;

public interface WhishListService {
	
	public ResponseEntity<?> getWhishlistByUserId(String userId);
	
	public ResponseEntity<?> addNewsToWhishlist(WhishList whishlist);
	
	public ResponseEntity<?> deleteFromWhishList(Long id);
	
	public ResponseEntity<?> updateWhishList(Long id,WhishList whishlist);
	
	public ResponseEntity<?> getAllNewsWhishlist();

}
