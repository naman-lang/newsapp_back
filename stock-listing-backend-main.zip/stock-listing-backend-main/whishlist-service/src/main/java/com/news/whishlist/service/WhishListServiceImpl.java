package com.news.whishlist.service;

import java.util.List;
import java.util.Optional;

import com.news.whishlist.dto.WhishList;
import com.news.whishlist.exception.ResourceAlreadyExistsException;
import com.news.whishlist.exception.ResourceNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.news.whishlist.repo.WhishListRepo;

@Service
public class WhishListServiceImpl implements WhishListService{

	@Autowired
	WhishListRepo whishListRepo;
	
	@Override
	public ResponseEntity<?> getWhishlistByUserId(String userId) {
		List<WhishList> whishlist = whishListRepo.findByUserId(userId);
		if(whishlist.isEmpty()) {
			throw new ResourceNotFoundException("item with given id not found");
		}
		return new ResponseEntity<>(whishlist, HttpStatus.OK);
	}

	@Override
	public ResponseEntity<?> addNewsToWhishlist(WhishList whishlist) {
		if(whishListRepo.existsByTitle(whishlist.getTitle())) {
			throw new ResourceAlreadyExistsException("item in whishlist already exists");
		}
		return new ResponseEntity<>(whishListRepo.save(whishlist), HttpStatus.CREATED);
	}

	@Override
	public ResponseEntity<?> deleteFromWhishList(Long id) {
		Optional<WhishList> whishlist = whishListRepo.findById(id);
		if(whishlist.isEmpty()) {
			throw new ResourceNotFoundException("item with given id not found");
		}
		whishListRepo.deleteById(id);
		return new ResponseEntity<>("item deleted successfully", HttpStatus.OK);
	}

	@Override
	public ResponseEntity<?> updateWhishList(Long id, WhishList whishlist) {
		Optional<WhishList> whishlistdb = whishListRepo.findById(id);
		if(whishlistdb.isEmpty()) {
			whishListRepo.save(whishlist);
		}
		whishlistdb.get().setName(whishlist.getName());
		whishlistdb.get().setDescription(whishlist.getDescription());
		whishlistdb.get().setContent(whishlist.getContent());
		whishlistdb.get().setAuthor(whishlist.getAuthor());
		whishlistdb.get().setTitle(whishlist.getTitle());
		whishlistdb.get().setPublishedAt(whishlist.getPublishedAt());
		whishlistdb.get().setUrl(whishlist.getUrl());
		whishlistdb.get().setUrlToImage(whishlist.getUrlToImage());
		WhishList updated = whishListRepo.save(whishlistdb.get());
		return new ResponseEntity<>(updated, HttpStatus.OK);
	}

	@Override
	public ResponseEntity<?> getAllNewsWhishlist() {
		return new ResponseEntity<>(whishListRepo.findAll(), HttpStatus.OK);
	}

}
