package com.news.whishlist.repo;

import java.util.List;
import java.util.Optional;

import com.news.whishlist.dto.WhishList;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface WhishListRepo extends JpaRepository<WhishList, Long>{
	
	List<WhishList> findByUserId(String userId);
	
	Optional<WhishList> findByTitle(String symbol);
	
	boolean existsByTitle(String symbol);
}
