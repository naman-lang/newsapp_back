package com.news.authservice.service;

import java.util.Optional;

import org.springframework.http.ResponseEntity;

import com.news.authservice.dto.LoginDto;
import com.news.authservice.dto.ResetDto;
import com.news.authservice.dto.SignupDto;
import com.news.authservice.model.User;
import com.news.userprofile.model.UserProfile;

public interface UserService {

	public ResponseEntity<?> addUser(SignupDto signupDto);
	
	//kafka service
	public ResponseEntity<?> registerUser(UserProfile signupDto);

	// this will work like a authentication manager for validating user
	public boolean loginUser(LoginDto loginDto);

	public ResponseEntity<?> getAllUsers();

	public Optional<User> getUserByUsername(String username);

	public ResponseEntity<?> updatePassword(ResetDto resetDto);

	public ResponseEntity<?> deleteUser(Long userId);

}
